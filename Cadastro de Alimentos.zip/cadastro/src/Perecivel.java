import java.util.Calendar;

public class Perecivel extends produto {

    private int[] validade = new int[3];   

    public Perecivel(String descricao, double valor, int[] validade) {

        super(descricao, valor);
        this.validade = validade;
    }

    public boolean estaVencido() {
        Calendar hoje = Calendar.getInstance();
        int dia = hoje.get(Calendar.DAY_OF_MONTH); // dia atual 
        int mes = hoje.get(Calendar.MONTH) + 1;   // mes atual    
        int ano = hoje.get(Calendar.YEAR);        // ano atual 

        int diasValidos = dia + mes * 30 + ano * 365;   // dia atual que esta no calendario 
        int diasValidade = validade[0] + validade[1] * 30 + validade[2] * 365;

        if (diasValidos > diasValidade) {  // se o dia atual for maior que o dia inserido, o produto esta vencido
            return true;
        }
        return false;

    }

    public void Aplicadesconto(double porcentagem) {
        super.setValor(super.getValor() * (100 - porcentagem)/100); // calcula a porcentagem do produto 

    }

    @Override

    public String toString() {
        return super.getDescricao() + " - Valor: " + super.getValor() + " - Validade: " + validade[0] + "/"
                + validade[1] + "/" + validade[2];
    }

}
