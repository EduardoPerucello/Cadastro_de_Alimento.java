import java.util.Scanner;

public class TestaProduto {
    static public boolean continuar = true;
    private static Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao;

        while (continuar) {
            System.out.println("Digite qual opcao voce quer:");
            System.out.println("[1] Criar um produto");
            System.out.println("[2] Criar um produto perecivel");
            System.out.println("[3] Sair do programa");
            opcao = in.nextInt();

            switch (opcao) {
                case 1:
                    opcao1();
                    break;

                case 2:
                    opcao2();
                    break;

                default:
                    System.exit(0);
            }
        }
    }

    public static void opcao1() {

        produto produto;
        String descricao;
        double valor;

        System.out.println("Digite a descricao do produto ");
        descricao = new String(in.next());
        System.out.println("Digite o valor do produto ");
        valor = in.nextDouble();
        System.out.printf("valor" + valor);
        System.out.println();

        produto = new produto(descricao, valor);

        System.out.printf("Dados do produto:" + produto.toString());
        System.out.println();

        continuar = true;
    }

    public static void opcao2() {

        Perecivel perecivel;
        String descricao;
        double valor;
        int[] validade = new int[3];
        double porcento;

        System.out.println("Digite a descricao do produto ");
        descricao = new String(in.next());
        System.out.println("Digite o valor do produto ");
        valor = in.nextDouble();
        System.out.println("Digite a validade do produto ");
        for (int i = 0; i < 3; i++) {
            validade[i] = in.nextInt();
        }

        perecivel = new Perecivel(descricao, valor, validade);

        System.out.println("Dados do produto:" + perecivel.toString());

        if (perecivel.estaVencido()) {
            System.out.println("O produto esta vencido");
        } else {
            System.out.println("O produto nao esta vencido");
        }

        System.out.println("Digite a quanto de desconto voce quer dar a este produto");
        porcento = in.nextDouble();

        perecivel.Aplicadesconto(porcento);

        System.out.printf("Dados do produto:" + perecivel.toString());
        System.out.println();

        continuar = true;
    }
}
