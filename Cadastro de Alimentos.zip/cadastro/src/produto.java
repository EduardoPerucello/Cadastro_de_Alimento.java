public class produto {
    String descricao;
    int id;
    double valor;
    static  int quantidade;

    public produto(String descricao, double valor) {
        quantidade++;
        this.descricao = descricao;
        this.valor = valor;
        this.id = quantidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getId() {
        return id;
    }

    public double getValor() {
        return valor;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String toString() {
         return "produto{" +
                "descricao='" + descricao + '\'' +
                ", id=" + id +
                ", valor=" + valor +
                '}';
    }
    

}
